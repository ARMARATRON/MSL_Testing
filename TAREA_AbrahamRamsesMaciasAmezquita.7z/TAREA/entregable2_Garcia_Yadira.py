def writefile():#ATENCION ESTE ES EL ENTREGABLE 2  este archivo es el que se 
    #entrega y el txt
    f = open('ejemplo.txt','w')
    f.write('Abraham Ramses Macias Amezquita')
    f.close()
    del f

def readfile():
    f = open('ejemplo.txt','r')
    leer = f.read()
    f.close()
    del f
    print(leer)


def automatizacion():
    from pathlib import Path
    HERE = path.abspath('./')
    folderFullPath = Path(HERE+'/IBM')
    folderFullPath.mkdir(parents=True, exist_ok=True)
    f=open('prueba.txt','w')
    f.write('International Business Machines Corporation')
    f.close()
    del f
    rename(HERE+'/prueba.txt',HERE+'/IBM/new_prueba.txt')
    folderFullPath.rename('MSL_Test')

def automatizacion2():#en este quite el import y uso del os .... path
    from pathlib import Path
    HERE = str(Path('./').absolute())
    print("HERE::::",HERE)
    folderFullPath = Path(HERE+'/IBM')
    folderFullPath.mkdir(parents=True, exist_ok=True)
    fil = Path(str(folderFullPath)+'/prueba.txt')
    print(fil.absolute())
    f=open(str(fil.absolute()),'w')
    f.write('International Business Machines Corporation')
    f.close()
    del f
    fil.rename(str(folderFullPath)+'/new_prueba.txt')
    folderFullPath.rename('MSL_Test')

def searchTextInFile(inText,file_path):
    with open(file_path, 'r') as file:
        content = file.read()
        #print(content)
        if inText in content:
            print('string exist in a file')
            for line in content.split('\n'):
        # check if string present on a current line
                if line.find(inText) != -1:
                    print('Line Number:', content.split('\n').index(line))
                    print('Line:', line)
        else:
            print('string does not exist in a file')

if __name__== '__main__':
    from os import path, rename 
    #writefile()
    #readfile()
    #automatizacion2()
    searchTextInFile('Failed password for root',path.abspath('./')+'/secure.log')


